document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Thank you for contacting us!');
    // Here you can add code to actually handle the form submission, e.g., via AJAX
});